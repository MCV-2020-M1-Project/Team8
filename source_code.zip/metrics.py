import cv2 as cv
import numpy as np


def cosine(x, y):
    """
    Compare histograms based on cosine similarity
    """
    return 1 - np.dot(x, y)/(np.linalg.norm(np.array(x)) * np.linalg.norm(np.array(y)))


def euclidean(x, y):
    """
    Compare histograms based on euclidean distance
    """
    return np.linalg.norm(np.array(x) - np.array(y))


def hellinger_kernel(x, y):
    """
    Compare histograms based on the Hellinger kernel
    """
    return cv.compareHist(x, y, cv.HISTCMP_HELLINGER)


def chi_square(x, y):
    """
    Compare histograms based on Chi-Square
    """
    return cv.compareHist(x, y, cv.HISTCMP_CHISQR)


def correlation(x, y):
    """
    Compare histograms by correlation
    """
    return 1 - cv.compareHist(x, y, cv.HISTCMP_CORREL)


def intersection(x, y):
    """
    Compare histograms by correlation
    """
    return -cv.compareHist(x, y, cv.HISTCMP_INTERSECT)


def levenshtein(index, query):
    if len(index) == 0 and len(query) > 0:
        return 1000000
    size_x = len(index) + 1
    size_y = len(query) + 1
    matrix = np.zeros((size_x, size_y))
    for x in xrange(size_x):
        matrix[x, 0] = x
    for y in xrange(size_y):
        matrix[0, y] = y

    for x in xrange(1, size_x):
        for y in xrange(1, size_y):
            if index[x-1] == query[y-1]:
                matrix[x, y] = min(matrix[x-1, y] + 1, matrix[x-1, y-1], matrix[x, y-1] + 1)
            else:
                matrix[x, y] = min(matrix[x-1, y] + 1, matrix[x-1, y-1] + 1, matrix[x, y-1] + 1)
    # print (matrix)
    return matrix[size_x - 1, size_y - 1]


def kullback_leibler_divergence(x, y):
    p = np.asarray(x)
    q = np.asarray(y)
    filt = np.logical_and(p != 0, q != 0)
    return np.sum(p[filt] * np.log2(p[filt] / q[filt]))


METRICS = {
    "cosine": cosine,
    "euclidean": euclidean,
    "hellinger_kernel": hellinger_kernel,
    "chi_square": chi_square,
    "correlation": correlation,
    "intersection": intersection,
    "levenshtein": levenshtein
}


def compute_distance(name, x, y):
    return METRICS[name](x, y)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    metric = "levenshtein"
    print('try {} metric: distance = {}'.format(metric, compute_distance(metric, 'text', 'test')))
