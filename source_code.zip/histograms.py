# coding=utf-8
# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.

import os
import cv2 as cv
import numpy as np
from skimage.feature import local_binary_pattern


def gray_histogram(path, mask_path=None):
    """
    compute histogram of an image in grayscale
    params:
        path: A path that specifies the location of image
        mask_path: corresponding mask
    return:
        hist: 1D histogram.
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
    hist = cv.calcHist([gray], [0], mask, [256], [0, 256])
    hist = cv.normalize(hist, hist).flatten()
    return hist


def hsv_1d_histogram(path, mask_path=None):
    """
    compute 1D histogram of an image in HSV color space
    params:
        path: A path that specifies the location of image
        mask_path: corresponding mask
    return:
        hist: 3D histogram flatted into an 1D array.
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    hsv = cv.cvtColor(image, cv.COLOR_BGR2HSV)
    channels = cv.split(hsv)
    hists = []
    # we should focus more on hue channel to distinguish colors
    # lighting/brightness channel is not necessarily divided into too many bins
    for channel, bin_val, max_val in zip(channels, [180, 256, 8], [180, 256, 256]):
        hist = cv.calcHist([channel], [0], mask, [bin_val], [0, max_val])
        hist = cv.normalize(hist, hist)
        hists.extend(hist)
    # flatten into a 1D array
    return np.stack(hists).flatten()


def rgb_1d_histogram(path, mask_path=None):
    """
    compute 1D histogram of an image in RGB color space
    params:
        path: A path that specifies the location of image
        mask_path: corresponding mask
    return:
        hist: 3D histogram flatted into an 1D array.
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    hsv = cv.cvtColor(image, cv.COLOR_BGR2RGB)
    channels = cv.split(hsv)
    hists = []
    for channel in channels:
        hist = cv.calcHist([channel], [0], mask, [256], [0, 256])
        hist = cv.normalize(hist, hist)
        hists.extend(hist)
    # flatten into a 1D array
    return np.stack(hists).flatten()


def ycrcb_1d_histogram(path, mask_path=None):
    """
    compute 1D histogram of an image in YCrCb color space
    params:
        path: A path that specifies the location of image
        mask_path: corresponding mask
    return:
        hist: 3D histogram flatted into an 1D array.
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    ycrcb = cv.cvtColor(image, cv.COLOR_BGR2YCrCb)
    channels = cv.split(ycrcb)
    hists = []
    for channel in channels:
        hist = cv.calcHist([channel], [0], mask, [256], [0, 256])
        hist = cv.normalize(hist, hist)
        hists.extend(hist)
    # flatten into a 1D array
    return np.stack(hists).flatten()


def lab_1d_histogram(path, mask_path=None):
    """
    compute 1D histogram of an image in LAB color space
    params:
        path: A path that specifies the location of image
        mask_path: corresponding mask
    return:
        hist: 3D histogram flatted into an 1D array.
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    lab = cv.cvtColor(image, cv.COLOR_BGR2Lab)
    channels = cv.split(lab)
    hists = []
    for channel in channels:
        hist = cv.calcHist([channel], [0], mask, [256], [0, 256])
        hist = cv.normalize(hist, hist)
        hists.extend(hist)
    # flatten into a 1D array
    return np.stack(hists).flatten()


def hsv_3d_histogram(path, mask_path=None):
    """
    compute 3D histogram of an image in HSV color space
    params:
        path: A path that specifies the location of image
        mask_path: corresponding mask
    return:
        hist: 3D histogram flatted into an 1D array.
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    hsv = cv.cvtColor(image, cv.COLOR_BGR2HSV)
    # we should focus more on hue channel to distinguish colors
    # lighting/brightness channel is not necessarily divided into too many bins
    hist = cv.calcHist([hsv], [0, 1, 2], mask, [18, 8, 8], [0, 180, 0, 256, 0, 256])
    hist = cv.normalize(hist, hist).flatten()
    return hist


def rgb_3d_histogram(path, mask_path=None):
    """
    compute 3D histogram of an image in RGB color space
    params:
        path: path pointing to the image to compute
        mask_path: corresponding mask
    return:
        hist: 3D histogram flatted into an 1D array.
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    rgb = cv.cvtColor(image, cv.COLOR_BGR2RGB)
    hist = cv.calcHist([rgb], [0, 1, 2], mask, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    hist = cv.normalize(hist, hist).flatten()
    return hist


def ycrcb_3d_histogram(path, mask_path=None):
    """
    compute 3D histogram of an image in YCrCb color space
    params:
        path: path pointing to the image to compute
        mask_path: corresponding mask
    returns:
        hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    ycrcb = cv.cvtColor(image, cv.COLOR_BGR2YCrCb)
    hist = cv.calcHist([ycrcb], [0, 1, 2], mask, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    hist = cv.normalize(hist, hist)
    return hist.flatten()


def lab_3d_histogram(path, mask_path=None):
    """
    compute 3D histogram of an image in lab color space
    params:
        path: path pointing to the image to compute
        mask_path: corresponding mask
    returns:
        hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    mask = cv.bitwise_not(cv.imread(mask_path, 0)) if mask_path is not None else None
    lab = cv.cvtColor(image, cv.COLOR_BGR2Lab)
    hist = cv.calcHist([lab], [0, 1, 2], mask, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    hist = cv.normalize(hist, hist)
    return hist.flatten()


def block_histogram_4_rgb(path, mask_path=None, seg=4):
    """
        compute block histogram of an image in rgb color space
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        returns:
            hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    image_tiles = split_image(image, seg)

    hists = []
    if mask_path is not None:
        mask = cv.bitwise_not(cv.imread(mask_path, 0))
        mask_tiles = split_image(mask, seg)
        for (image_tile, mask_tile) in zip(image_tiles, mask_tiles):  # for each tile
            # rgb
            rgb = cv.cvtColor(image_tile, cv.COLOR_BGR2RGB)
            t_hist = cv.calcHist([rgb], [0, 1, 2], mask_tile, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist).flatten()
            hists.extend(t_hist)
    else:
        for image_tile in image_tiles:  # for each tile
            # rgb
            rgb = cv.cvtColor(image_tile, cv.COLOR_BGR2RGB)
            t_hist = cv.calcHist([rgb], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist).flatten()
            hists.extend(t_hist)
    return np.stack(hists).flatten()


def block_histogram_4_hsv(path, mask_path=None, seg=4):
    """
        compute block histogram of an image in HSV color space
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        returns:
            hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    image_tiles = split_image(image, seg)
    hists = []
    if mask_path is not None:
        mask = cv.bitwise_not(cv.imread(mask_path, 0))
        mask_tiles = split_image(mask, seg)

        for (image_tile, mask_tile) in zip(image_tiles, mask_tiles):  # for each tile
            # hsv
            hsv = cv.cvtColor(image_tile, cv.COLOR_BGR2HSV)  # convert tile to hsv
            hs = cv.split(hsv)[0:2]  # only calculate for hs
            t_hist = []  # hist for 1 tile
            for c, bin_val, max_val in zip(hs, [180, 64], [180, 256]):
                c_hist = cv.calcHist([c], [0], mask_tile, [bin_val], [0, max_val])  # hist for 1 channel
                c_hist = cv.normalize(c_hist, c_hist).flatten()
                t_hist.extend(c_hist)
            hists.extend(t_hist)
    else:
        for image_tile in image_tiles:  # for each tile
            # hsv
            hsv = cv.cvtColor(image_tile, cv.COLOR_BGR2HSV)  # convert tile to hsv
            hs = cv.split(hsv)[0:2]  # only calculate for hs
            t_hist = []  # hist for 1 tile
            for c, bin_val, max_val in zip(hs, [180, 64], [180, 256]):
                c_hist = cv.calcHist([c], [0], None, [bin_val], [0, max_val])  # hist for 1 channel
                c_hist = cv.normalize(c_hist, c_hist).flatten()
                t_hist.extend(c_hist)
            hists.extend(t_hist)
    return np.stack(hists).flatten()


def block_histogram_4_ycrcb(path, mask_path=None, seg=4):
    """
        compute block histogram of an image in YCrCb color space
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        returns:
            hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    image_tiles = split_image(image, seg)
    hists = []
    if mask_path is not None:
        mask = cv.bitwise_not(cv.imread(mask_path, 0))
        mask_tiles = split_image(mask, seg)
        for (image_tile, mask_tile) in zip(image_tiles, mask_tiles):  # for each tile
            # ycrcb
            ycrcb = cv.cvtColor(image_tile, cv.COLOR_BGR2YCrCb)
            t_hist = cv.calcHist([ycrcb], [0, 1, 2], mask_tile, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist)
            hists.extend(t_hist)
    else:
        for image_tile in image_tiles:  # for each tile
            # ycrcb
            ycrcb = cv.cvtColor(image_tile, cv.COLOR_BGR2YCrCb)
            t_hist = cv.calcHist([ycrcb], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist)
            hists.extend(t_hist)
    return np.stack(hists).flatten()


def block_histogram_4_lab(path, mask_path=None, seg=4):
    """
        compute block histogram of an image in Lab color space
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        returns:
            hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    image_tiles = split_image(image, seg)
    hists = []
    if mask_path is not None:
        mask = cv.bitwise_not(cv.imread(mask_path, 0))
        mask_tiles = split_image(mask, seg)
        for (image_tile, mask_tile) in zip(image_tiles, mask_tiles):  # for each tile
            # lab
            lab = cv.cvtColor(image_tile, cv.COLOR_BGR2Lab)
            t_hist = cv.calcHist([lab], [0, 1, 2], mask_tile, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist)
            hists.extend(t_hist)
    else:
        for image_tile in image_tiles:  # for each tile
            # lab
            lab = cv.cvtColor(image_tile, cv.COLOR_BGR2Lab)
            t_hist = cv.calcHist([lab], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist)
            hists.extend(t_hist)
    return np.stack(hists).flatten()


def spatial_pyramid_histogram_hsv(path, mask_path=None):
    """
        compute spatial pyramid histogram of an image in HSV color space
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        returns:
            hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)

    image_tiles = []
    image_tiles.extend(split_image(image, 1))
    image_tiles.extend(split_image(image, 2))
    image_tiles.extend(split_image(image, 4))
    hists = []
    if mask_path is not None:
        mask = cv.bitwise_not(cv.imread(mask_path, 0))
        mask_tiles = []
        mask_tiles.extend(split_image(mask, 1))
        mask_tiles.extend(split_image(mask, 2))
        mask_tiles.extend(split_image(mask, 4))

        for (image_tile, mask_tile) in zip(image_tiles, mask_tiles):  # for each tile
            # hsv
            hsv = cv.cvtColor(image_tile, cv.COLOR_BGR2HSV)  # convert tile to hsv
            hs = cv.split(hsv)[0:2]  # only calculate for hs
            t_hist = []  # hist for 1 tile
            for c, bin_val, max_val in zip(hs, [180, 64], [180, 256]):
                c_hist = cv.calcHist([c], [0], mask_tile, [bin_val], [0, max_val])  # hist for 1 channel
                c_hist = cv.normalize(c_hist, c_hist).flatten()
                t_hist.extend(c_hist)
            hists.extend(t_hist)
    else:
        for image_tile in image_tiles:  # for each tile
            # hsv
            hsv = cv.cvtColor(image_tile, cv.COLOR_BGR2HSV)  # convert tile to hsv
            hs = cv.split(hsv)[0:2]  # only calculate for hs
            t_hist = []  # hist for 1 tile
            for c, bin_val, max_val in zip(hs, [180, 64], [180, 256]):
                c_hist = cv.calcHist([c], [0], None, [bin_val], [0, max_val])  # hist for 1 channel
                c_hist = cv.normalize(c_hist, c_hist).flatten()
                t_hist.extend(c_hist)
            hists.extend(t_hist)
    return np.stack(hists).flatten()


def spatial_pyramid_histogram_rgb(path, mask_path=None):
    """
        compute spatial pyramid histogram of an image in RGB color space
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        returns:
            hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    image_tiles = []
    image_tiles.extend(split_image(image, 1))
    image_tiles.extend(split_image(image, 2))
    image_tiles.extend(split_image(image, 4))
    hists = []
    if mask_path is not None:
        mask = cv.bitwise_not(cv.imread(mask_path, 0))
        mask_tiles = []
        mask_tiles.extend(split_image(mask, 1))
        mask_tiles.extend(split_image(mask, 2))
        mask_tiles.extend(split_image(mask, 4))

        for (image_tile, mask_tile) in zip(image_tiles, mask_tiles):  # for each tile
            # rgb
            rgb = cv.cvtColor(image_tile, cv.COLOR_BGR2RGB)
            t_hist = cv.calcHist([rgb], [0, 1, 2], mask_tile, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist).flatten()
            hists.extend(t_hist)
    else:
        for image_tile in image_tiles:  # for each tile
            # rgb
            rgb = cv.cvtColor(image_tile, cv.COLOR_BGR2RGB)
            t_hist = cv.calcHist([rgb], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist).flatten()
            hists.extend(t_hist)
    return np.stack(hists).flatten()


def spatial_pyramid_histogram_ycrcb(path, mask_path=None):
    """
        compute spatial pyramid histogram of an image in YCrCb color space
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        returns:
            hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    image_tiles = []
    image_tiles.extend(split_image(image, 1))
    image_tiles.extend(split_image(image, 2))
    image_tiles.extend(split_image(image, 4))
    hists = []
    if mask_path is not None:
        mask = cv.bitwise_not(cv.imread(mask_path, 0))
        mask_tiles = []
        mask_tiles.extend(split_image(mask, 1))
        mask_tiles.extend(split_image(mask, 2))
        mask_tiles.extend(split_image(mask, 4))
        for (image_tile, mask_tile) in zip(image_tiles, mask_tiles):  # for each tile
            # ycrcb
            ycrcb = cv.cvtColor(image_tile, cv.COLOR_BGR2YCrCb)
            t_hist = cv.calcHist([ycrcb], [0, 1, 2], mask_tile, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist)
            hists.extend(t_hist)
    else:
        for image_tile in image_tiles:  # for each tile
            # ycrcb
            ycrcb = cv.cvtColor(image_tile, cv.COLOR_BGR2YCrCb)
            t_hist = cv.calcHist([ycrcb], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist)
            hists.extend(t_hist)
    return np.stack(hists).flatten()


def spatial_pyramid_histogram_lab(path, mask_path=None):
    """
        compute spatial pyramid histogram of an image in Lab color space
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        returns:
            hist: 3D histogram flatted into an 1D array
    """
    image = cv.imread(path)
    image_tiles = []
    image_tiles.extend(split_image(image, 1))
    image_tiles.extend(split_image(image, 2))
    image_tiles.extend(split_image(image, 4))

    hists = []
    if mask_path is not None:
        mask = cv.bitwise_not(cv.imread(mask_path, 0))
        mask_tiles = []
        mask_tiles.extend(split_image(mask, 1))
        mask_tiles.extend(split_image(mask, 2))
        mask_tiles.extend(split_image(mask, 4))
        for (image_tile, mask_tile) in zip(image_tiles, mask_tiles):  # for each tile
            # lab
            lab = cv.cvtColor(image_tile, cv.COLOR_BGR2Lab)
            t_hist = cv.calcHist([lab], [0, 1, 2], mask_tile, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist)
            hists.extend(t_hist)
    else:
        for image_tile in image_tiles:  # for each tile
            # lab
            lab = cv.cvtColor(image_tile, cv.COLOR_BGR2Lab)
            t_hist = cv.calcHist([lab], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
            t_hist = cv.normalize(t_hist, t_hist)
            hists.extend(t_hist)
    return np.stack(hists).flatten()


def lbp_histogram(path, mask_path=None):
    """
        Compute the histogram of the local binary image of an input image
        params:
            path: path pointing to the image to compute
            mask_path: corresponding mask
        return:
            lbp_hist: the local binary pattern histogram of the input image
    """

    method = 'uniform'
    radius = 3
    n_points = 24
    # n_bins = 2 ** n_points

    image = cv.cvtColor(cv.imread(path), cv.COLOR_BGR2GRAY)
    lbp = local_binary_pattern(image, n_points, radius, method)
    n_bins = n_points + 2
    lbp_tiles = []
    lbp_tiles.extend(split_image(lbp, 8))
    lbp_hist = []
    if mask_path is not None:
        mask = (cv.bitwise_not(cv.imread(mask_path, 0)) > 0)
        mask_tiles = []
        mask_tiles.extend(split_image(mask, 8))
        for (lbp_tile, mask_tile) in zip(lbp_tiles, mask_tiles):
            hist, _ = np.histogram(lbp_tile[mask_tile], bins=n_bins, range=(0, n_bins))
            lbp_hist.extend(hist)
        # lbp_hist, _ = np.histogram(lbp[mask], n_bins, (0, n_bins))
    else:
        for lbp_tile in lbp_tiles:
            hist, _ = np.histogram(lbp_tile, bins=n_bins, range=(0, n_bins))
            lbp_hist.extend(hist)
        # lbp_hist, _ = np.histogram(lbp.ravel(), n_bins, (0, n_bins))
    return np.stack(lbp_hist).flatten().astype(np.float32)


def split_image(img, seg=2):
    M = img.shape[0]//seg
    N = img.shape[1]//seg
    tiles = []
    for i in range(0, seg):
        start_x = i*M
        end_x = i*M + M if i != seg - 1 else img.shape[0]
        for j in range(0, seg):
            start_y = j*N
            end_y = j*N + N if j != seg - 1 else img.shape[1]
            tiles.append(img[start_x:end_x, start_y:end_y])
    return tiles


DESCRIPTOR_FUNCTIONS = {
    "gray_histogram": gray_histogram,
    "hsv_1d_histogram": hsv_1d_histogram,
    "rgb_1d_histogram": rgb_1d_histogram,
    "ycrcb_1d_histogram": ycrcb_1d_histogram,
    "lab_1d_histogram": lab_1d_histogram,
    "hsv_3d_histogram": hsv_3d_histogram,
    "rgb_3d_histogram": rgb_3d_histogram,
    "ycrcb_3d_histogram": ycrcb_3d_histogram,
    "lab_3d_histogram": lab_3d_histogram,
    "block_histogram_4_hsv": block_histogram_4_hsv,
    "block_histogram_4_rgb": block_histogram_4_rgb,
    "block_histogram_4_ycrcb": block_histogram_4_ycrcb,
    "block_histogram_4_lab": block_histogram_4_lab,
    "spatial_pyramid_histogram_hsv": spatial_pyramid_histogram_hsv,
    "spatial_pyramid_histogram_rgb": spatial_pyramid_histogram_rgb,
    "spatial_pyramid_histogram_ycrcb": spatial_pyramid_histogram_ycrcb,
    "spatial_pyramid_histogram_lab": spatial_pyramid_histogram_lab,
    "lbp_histogram": lbp_histogram
}


def compute_descriptor(descriptor, path, mask=None):
    return DESCRIPTOR_FUNCTIONS[descriptor](path, mask)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    name = "lbp_histogram"
    print('try {}: shape = {}'.format(name, compute_descriptor(name, os.path.join('images', 'bbdd_00001.jpg')).shape))